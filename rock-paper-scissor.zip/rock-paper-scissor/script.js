// Selecting DOM elements
const player1Section = document.getElementById('player1-section');
const player2Section = document.getElementById('player2-section');
const turnIndicator = document.getElementById('turnIndicator');
const timerDisplay = document.getElementById('timer');
const winnerPopup = document.getElementById('winnerPopup');
const winnerMessage = document.getElementById('winnerMessage');
const winnerImage = document.querySelector('.popup img');
const restartBtn = document.getElementById('restartBtn');

// Game state variables
let player1Choice = null;
let player2Choice = null;
let currentRound = 1;
let player1Score = 0;
let player2Score = 0;

// Initialize the game
function startGame() {
    resetGame();
    playerTurn(1);
}

// Reset game state and UI
function resetGame() {
    player1Choice = null;
    player2Choice = null;
    player1Score = 0;
    player2Score = 0;
    currentRound = 1;
    winnerPopup.style.display = 'none';
    player1Section.style.pointerEvents = 'none';
    player2Section.style.pointerEvents = 'none';
    timerDisplay.textContent = '';
    turnIndicator.textContent = '';
}

// Handle player turns
function playerTurn(player) {
    turnIndicator.textContent = `Player ${player}'s Turn`;
    const activeSection = player === 1 ? player1Section : player2Section;
    const inactiveSection = player === 1 ? player2Section : player1Section;
    activeSection.style.pointerEvents = 'auto';
    inactiveSection.style.pointerEvents = 'none';

    let countdown = 5;
    timerDisplay.textContent = countdown;

    const timer = setInterval(() => {
        countdown--;
        timerDisplay.textContent = countdown;

        // If timer runs out, auto-assign "none" as the choice
        if (countdown < 0) {
            clearInterval(timer);
            if (player === 1) {
                player1Choice = player1Choice || 'none';
                playerTurn(2);
            } else {
                player2Choice = player2Choice || 'none';
                evaluateRound();
            }
        }
    }, 1000);

    // Add event listeners for choices
    const choices = activeSection.querySelectorAll('.choice');
    choices.forEach((choice) => {
        choice.addEventListener('click', () => {
            if (player === 1) {
                player1Choice = choice.dataset.choice;
            } else {
                player2Choice = choice.dataset.choice;
            }
            clearInterval(timer);
            if (player === 1) {
                playerTurn(2);
            } else {
                evaluateRound();
            }
        });
    });
}

// Evaluate the result of the round
function evaluateRound() {
    let resultMessage = '';
    let isDraw = false;

    if (player1Choice === player2Choice) {
        isDraw = true;
        resultMessage = "It's a draw!";
        winnerImage.src = 'https://i.postimg.cc/rpbv2Yrr/download-2.png'; // Draw image
    } else if (
        (player1Choice === 'rock' && player2Choice === 'scissors') ||
        (player1Choice === 'scissors' && player2Choice === 'paper') ||
        (player1Choice === 'paper' && player2Choice === 'rock')
    ) {
        player1Score++;
        resultMessage = 'Player 1 wins this round!';
        winnerImage.src = 'https://i.postimg.cc/3xYfMQf6/success-1.png'; // Win image
    } else {
        player2Score++;
        resultMessage = 'Player 2 wins this round!';
        winnerImage.src = 'https://i.postimg.cc/3xYfMQf6/success-1.png'; // Win image
    }

    // Display popup
    winnerPopup.style.display = 'block';
    winnerMessage.textContent = resultMessage;

    // Move to the next round or end the game
    setTimeout(() => {
        winnerPopup.style.display = 'none';
        if (currentRound < 3) {
            currentRound++;
            player1Choice = null;
            player2Choice = null;
            playerTurn(1);
        } else {
            declareWinner();
        }
    }, 3000);
}

// Declare the winner of the game
function declareWinner() {
    let finalMessage = '';
    let isDraw = false;

    if (player1Score > player2Score) {
        finalMessage = 'Player 1 is the Winner!';
        winnerImage.src = 'https://i.postimg.cc/3xYfMQf6/success-1.png'; // Win image
    } else if (player2Score > player1Score) {
        finalMessage = 'Player 2 is the Winner!';
        winnerImage.src = 'https://i.postimg.cc/3xYfMQf6/success-1.png'; // Win image
    } else {
        isDraw = true;
        finalMessage = "It's a Draw!";
        winnerImage.src = 'https://i.postimg.cc/rpbv2Yrr/download-2.png'; // Draw image
    }

    winnerPopup.style.display = 'block';
    winnerPopup.style.backgroundColor = isDraw ? '#feca57' : '#2ecc71'; // Yellow for draw, green for win
    winnerMessage.textContent = finalMessage;
}

// Restart the game
restartBtn.addEventListener('click', () => {
    resetGame();
    startGame();
});

// Start the game on page load
startGame();
